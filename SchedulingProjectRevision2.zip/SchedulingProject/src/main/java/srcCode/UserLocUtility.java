package srcCode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.LocalDateTime;
import java.util.function.BiFunction;

/**
 * Checks user time for proper display
 *
 * Converts various date and time (UTC, EST, MST, PST) *
 *
 * Ensures the time of submission is current
 *
 * Alters language to French based on location
 */
public class UserLocUtility {

    public static String ConvertToUTC(String dateIn) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date d = df.parse(dateIn);
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        TimeZone userTimeZone = GetTimeZone();
        String sUTCOffset = FormatUtcOffset.apply(userTimeZone.getRawOffset() / (1000 * 60 * 60),
                Math.abs((userTimeZone.getRawOffset() / (1000 * 60)) % 60));
        String[] sUTCRay = sUTCOffset.split(":");
        int iSign = 1;
        if (Objects.equals(sUTCRay[0], "+"))
        {
            iSign = -1;
        }
        int iHour = Integer.parseInt(sUTCRay[1]) * iSign;
        cal.add(Calendar.HOUR,iHour);
        String sUTC = df.format(cal.getTime());
        return sUTC;
    }
    public static String ConvertToLocal(String dateIn ) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date d = df.parse(dateIn);
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        TimeZone userTimeZone = GetTimeZone();
        String sUTCOffset = FormatUtcOffset.apply(userTimeZone.getRawOffset() / (1000 * 60 * 60),
                Math.abs((userTimeZone.getRawOffset() / (1000 * 60)) % 60));
        String[] sUTCRay = sUTCOffset.split(":");
        int iSign = 1;
        if (Objects.equals(sUTCRay[0], "-"))
        {
            iSign = -1;
        }
        int iHour = Integer.parseInt(sUTCRay[1]) * iSign;
        cal.add(Calendar.HOUR,iHour);
        String sLocal = df.format(cal.getTime());
        return sLocal;
    }
    public static TimeZone GetTimeZone() {
        return TimeZone.getDefault();
    }

    public static LocalDateTime GetCurrentTime() {
        return LocalDateTime.now(ZoneId.systemDefault());
    }

    public static Locale GetUserLocale() {
        return Locale.getDefault();
    }

    public static String GetTranslation(Integer msgIndex)
    {
        String retMsg = "";
        switch (msgIndex)
        {
            case(1):
                retMsg = GetMessage.apply("Scheduling Application","Application de planification");
                break;
            case(2):
                retMsg = GetMessage.apply("Login","Se connecter");
                break;
            case(3):
                retMsg = GetMessage.apply("Username:","Nom d'utilisateur:");
                break;
            case(4):
                retMsg = GetMessage.apply("Password:","Mot de passe:");
                break;
            case(5):
                retMsg = GetMessage.apply("Exit","Sortie");
                break;
            case(6):
                retMsg = GetMessage.apply("User's Location:","Emplacement de l'utilisateur:");
                break;
            case (7):
                retMsg = GetMessage.apply("Please enter a username and password!","Veuillez entrer un nom d'utilisateur et un mot de passe!");
                break;
            case (8):
                retMsg = GetMessage.apply("Invalid username or password!","Nom d'utilisateur ou mot de passe invalide!");
                break;
            case (9):
                retMsg = GetMessage.apply("No upcoming appointments!","Aucun rendez-vous à venir!");
                break;
            case (10):
                retMsg = GetMessage.apply("Message","Message");
                break;
            case (11):
                retMsg = GetMessage.apply("Ok","D'accord");
                break;
            case (12):
                retMsg = GetMessage.apply("Upcoming appointment: ","Rendez-vous à venir: ");
                break;
            case (13):
                retMsg = GetMessage.apply("Mountain Standard Time","Heure normale des Rocheuses");
                break;
            case (14):
                retMsg = GetMessage.apply("Eastern Standard Time","Heure normale de l'Est");
                break;
            case (15):
                retMsg = GetMessage.apply("Pacific Standard Time","Heure Standard du Pacifique");
                break;
        }
        return retMsg;

    }
    public static boolean IsFrenchSpeaking() {
        return GetUserLocale().getLanguage().equals("fr") || GetUserLocale().getCountry().equals("CA")
                || GetUserLocale().getCountry().equals("FR") || GetUserLocale().getCountry().equals("BE")
                || GetUserLocale().getCountry().equals("CH") || GetUserLocale().getCountry().equals("LU");
    }

    /**
     * Lambda expression to format the UTC offset
     *
     * Improves formatting and filtering
     *
     * This BiFunction allows two inputs to determine UTC Offset
     * It is static and anonymous, so it does not get altered throughout the code
     */

    static BiFunction<Integer, Integer, String> FormatUtcOffset = (hours, minutes) ->
    {
        String sign = (hours >= 0) ? "+" : "-";
        return String.format("%s:%02d:%02d", sign, Math.abs(hours)-1, minutes);
    };

    /**
     * Lambda expression for language-specific messages
     *
     * BiFunction determines french characteristics and alters messages accordingly
     * This remains static and has no need to be called directly
     */
    static BiFunction<String, String, String> GetMessage = (englishMsg, frenchMsg) ->
    {
       return IsFrenchSpeaking() ? frenchMsg : englishMsg;
       //return IsFrenchSpeaking() ? englishMsg : frenchMsg;   //TEST
    };
    /**
     * Lambda usage simplifies the function of both expressions
     * Also makes them much more legible and 'clean' when reviewing the code
     */
}

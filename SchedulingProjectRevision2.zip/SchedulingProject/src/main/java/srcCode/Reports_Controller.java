package srcCode;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

/**
 * Creates reports check graphics
 *
 * Reports can be called, loaded, and displayed
 *
 * Makes sure there are no missing variables or errors
 */
public class Reports_Controller
{

        private int userID;
        @FXML
        private Button btnClose_fxid;

        @FXML
        private ToggleGroup grpReports;

        @FXML
        private ToggleButton togReport1_fxid;

        @FXML
        private ToggleButton togReport2_fxid;

        @FXML
        private ToggleButton togReport3_fxid;

        @FXML
        private TextArea txtReport_fxid;

        public void SetUserID(int iUserID)
        {
                userID = iUserID;
        }
        @FXML
        void togReport1_Click(ActionEvent event) throws SQLException, ParseException {
                LoadReport(1);
        }

        @FXML
        void togReport2_Click(ActionEvent event) throws SQLException, ParseException {
                LoadReport(2);
        }

        @FXML
        void togReport3_Click(ActionEvent event) throws SQLException, ParseException {
                LoadReport(3);
        }
        public void LoadReport(int iWhichReport) throws SQLException, ParseException {
                String query = "";
                int i;
                int iNumFields = 0;

                switch (iWhichReport)
                {
                        case 1:
                                query = "select monthname(start) as Month, type as Type, count(*) as Count from appointments  group by monthname(start), type order by month(start), type;";
                                iNumFields = 3;
                                break;
                        case 2:
                                query = "SELECT appointment_ID, title, description,  type, start, end, cu.customer_id,  co.contact_id, co.contact_name FROM Appointments a " +
                                        "LEFT JOIN Users u ON a.User_id = u.User_id LEFT JOIN Contacts co ON a.contact_id = co.contact_id LEFT JOIN Customers cu ON a.customer_id = cu.customer_id ORDER BY contact_name, start;";
                                iNumFields = 9;
                                break;
                        case 3:
                                query = "SELECT customer_id, customer_name, division, d.division_id, co.country, co.country_id FROM Customers cu LEFT JOIN First_Level_Divisions d ON cu.division_id = d.division_id LEFT JOIN Countries co ON d.Country_ID = co.Country_ID order by co.Country_ID, division;";
                               iNumFields = 6;
                                break;
                        default:
                                break;
                }
                if (query != "")
                {
                        DatabaseMySQL myConn = new DatabaseMySQL();
                        ResultSet rs = myConn.SubmitQuery(query);
                        String sReport = "";
                        while (rs.next())
                        {
                                for (i=1; i <= iNumFields; i++)
                                {
                                        if (i > 1)
                                        {
                                                sReport += ", ";
                                         }
                                        if ((iWhichReport == 2) && (i == 5 || i == 6))
                                        {
                                                sReport += UserLocUtility.ConvertToLocal(rs.getString(i));
                                        }
                                        else
                                        {
                                                sReport += rs.getString(i);
                                        }
                                }
                                sReport += "\r\n";
                        }
                        myConn.CloseConnection();
                        txtReport_fxid.setText(sReport);
                }
                else
                {
                        txtReport_fxid.setText("Invalid report number!");
                }
        }
        @FXML
        void btnClose_Click(ActionEvent event) throws IOException, SQLException {
                Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Customers.fxml"));
                Parent root = fxmlLoader.load();
                ManageCustomers_Controller conManageCust = fxmlLoader.getController();
                conManageCust.LoadCustomers(userID);
                Scene scene = new Scene(root);
                stage.setTitle("Customers");
                stage.setScene(scene);
                stage.show();
        }
}

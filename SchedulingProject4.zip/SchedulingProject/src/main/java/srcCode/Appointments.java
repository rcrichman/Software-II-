package srcCode;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public class Appointments
{
    private ObservableList<Appointment> allAppointments;
    private Integer appointmentID;

    public Appointments()
    {
        appointmentID = 0;
        allAppointments = FXCollections.observableArrayList();
    }

    public void AddAppointment(Appointment newAppointment) throws SQLException
    {
        if (newAppointment.getAppointment_id() == 0)
        {
            DatabaseMySQL myConn = new DatabaseMySQL();

            String query = "INSERT INTO Appointments (title, description, location, type, start, end, customer_id, user_id, contact_id) " +
                "VALUES('" + newAppointment.getTitle() + "','" + newAppointment.getDescription() + "','" + newAppointment.getLocation() +
            "','" + newAppointment.getType() + "','" + newAppointment.getStartDate() + "','" + newAppointment.getEndDate() +
            "'," + newAppointment.getCustomer_id() + "," + newAppointment.getUser_id() + "," + newAppointment.getContact_id() + ");";
            appointmentID = myConn.SubmitUpdateQuery(query,true);
            newAppointment.setAppointment_id(appointmentID);
            myConn.CloseConnection();
        }
        else
        {
            //UPDATE
        }
        allAppointments.add(newAppointment);

    }
    public void UpdateAppointment(Appointment originalAppointment, Appointment updatedAppointment)
    {
        allAppointments.remove(originalAppointment);
        allAppointments.add(updatedAppointment);
    }
    public void RemoveAppointment(Appointment removedAppointment)
    {
        allAppointments.remove(removedAppointment);
    }
    public ObservableList<Appointment> getAllAppointments()
    {
        return allAppointments;
    }
    public Integer getNumAppointments()
    {
        return allAppointments.size();
    }
}

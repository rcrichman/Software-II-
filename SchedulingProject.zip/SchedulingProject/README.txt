The title is called SchedulingProject. The goal is to allow user creation, appointment scheduling,
and a graphical interface that can be saved and referenced in a database.

My name is Russell Richman. Contact me through my email rric371@wgu.edu. This is version 1.0,
release as of current 6/26/2024 at 6:40 A.M.

The IDE information is as follows:
                  IntelliJ IDEA 2023.2.2 (Community Edition)
                  Build #IC-232.9921.47
                  Runtime version: 17.0.8+7-b1000.22 amd64
                  VM: OpenJDK 64-Bit Server VM by JetBrains s.r.o.
                  Windows 10.0
                  Oracle OpenJDK version 22.0.1
                  openjdk-22.0.1

                  openjfx-11.0.2_windows-x64_bin-sdk
                  javafx-sdk-17.0.1

                  mysql-connector-java-8.0.25

Open the folder SchedulingProject in Intellij. Make sure you have all proper files and proper connection to the database.
Select src: java: srcCode: SchedulingMain then hit Run. After that you must login, then you can begin creating, removing,
and viewing appointments.

I created a unique report that would depict which language or location created the most appointments.
This would be good for determining which audience is being properly reached, and where may use some work.
It could also help notice trends and other possible changes that could enhance user experience based on each
particular area.


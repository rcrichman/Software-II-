package srcCode;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.SQLException;
import java.text.ParseException;

/**
 * Develops and connects references to arrayed input values
 *
 * Allows appointment button input and output connected to data
 *
 * Allows the user to add, remove, update, and view their appointment
 */
public class Appointments
{
    private ObservableList<Appointment> allAppointments;
    private Integer appointmentID;

    public Appointments()
    {
        appointmentID = 0;
        allAppointments = FXCollections.observableArrayList();
    }

    public void AddAppointment(Appointment newAppointment,boolean bStoreIt) throws SQLException, ParseException {
        if (bStoreIt) {
            DatabaseMySQL myConn = new DatabaseMySQL();
            String startUTC = UserLocUtility.ConvertToUTC(newAppointment.getStartDate());
            String endUTC = UserLocUtility.ConvertToUTC(newAppointment.getEndDate());
            if (newAppointment.getAppointment_id() == 0) {
                String query = "INSERT INTO Appointments (title, description, location, type, start, end, customer_id, user_id, contact_id) " +
                        "VALUES('" + newAppointment.getTitle() + "','" + newAppointment.getDescription() + "','" + newAppointment.getLocation() +
                        "','" + newAppointment.getType() + "','" + startUTC + "','" + endUTC +
                        "'," + newAppointment.getCustomer_id() + "," + newAppointment.getUser_id() + "," + newAppointment.getContact_id() + ");";
                appointmentID = myConn.SubmitUpdateQuery(query, true);
                newAppointment.setAppointment_id(appointmentID);

            } else {
                String query = "UPDATE  Appointments SET title='" + newAppointment.getTitle() + "', description='" + newAppointment.getDescription() + "', location='" +
                        newAppointment.getLocation() + "', type='" + newAppointment.getType() + "', start='" + startUTC + "', end='" + endUTC +
                        "', customer_id=" + newAppointment.getCustomer_id() + ",user_id=" + newAppointment.getUser_id() + ",contact_id=" + newAppointment.getContact_id() +
                        " WHERE appointment_id = " + newAppointment.getAppointment_id() + ";";
                myConn.SubmitUpdateQuery(query, false);
            }
            myConn.CloseConnection();
        }
        allAppointments.add(newAppointment);

    }
    public void UpdateAppointment(Appointment originalAppointment, Appointment updatedAppointment) throws SQLException, ParseException {
        allAppointments.remove(originalAppointment);
        AddAppointment(updatedAppointment,true);
    }
    public void RemoveAppointment(Appointment removedAppointment) throws SQLException
    {

        DatabaseMySQL myConn = new DatabaseMySQL();

        String query = "DELETE FROM Appointments WHERE Appointment_ID =" + removedAppointment.getAppointment_id() + ";";
        myConn.SubmitUpdateQuery(query,false);
        myConn.CloseConnection();
        allAppointments.remove(removedAppointment);
    }
    public ObservableList<Appointment> getAllAppointments()
    {
        return allAppointments;
    }
    public Integer getNumAppointments()
    {
        return allAppointments.size();
    }
}

package srcCode;

import com.mysql.cj.x.protobuf.MysqlxSession;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import static java.lang.Integer.parseInt;

/**
 * Creates the overall display for managing appointments
 *
 * This includes buttons, inputs, layout, and other graphical features
 *
 * Also checks and makes sure the display is properly aligned without error
 */
public class ManageAppointments_Controller
{
    private int userID;
    private Boolean bNeedToSave;
    private Boolean bDateCheck;
    private Appointments clsAppointments;
    private Contacts clsContacts;
    private Customers clsCustomers;

    public ManageAppointments_Controller()
    {
        clsAppointments = new Appointments();
        clsContacts = new Contacts();
    }

    @FXML
    private Button btnAdd_fxi;


    @FXML
    private Button btnCancel_fxid;

    @FXML
    private Button btnDelete_fxid;

    @FXML
    private Button btnEdit_fxid;

    @FXML
    private Button btnExit_fxid;

    @FXML
    private Button btnSave_fxid;

    @FXML
    private ComboBox<String> cbContact_fxid;

    @FXML
    private ComboBox<String> cbCustomer_fxid;

    @FXML
    private ComboBox<String> cbStartTime_fxid;

    @FXML
    private ComboBox<String> cbEndTime_fxid;
    @FXML
    private TableColumn<?, ?> colApptID_fxid;

    @FXML
    private TableColumn<?, ?> colContact_fxid;

    @FXML
    private TableColumn<?, ?> colCustomerID_fxid;

    @FXML
    private TableColumn<?, ?> colDescription_fxid;

    @FXML
    private TableColumn<?, ?> colEndDate_fxid;

    @FXML
    private TableColumn<?, ?> colLocation_fxid;

    @FXML
    private TableColumn<?, ?> colStartDate_fxid;

    @FXML
    private TableColumn<?, ?> colTitle_fxid;

    @FXML
    private TableColumn<?, ?> colType_fxid;

    @FXML
    private TableColumn<?, ?> colUserID_fxid;

    @FXML
    private ToggleGroup grpCustAppt;

    @FXML
    private ToggleGroup grpApptFilter;

    @FXML
    private Label lblApptID_fxid;

    @FXML
    private Label lblContact_fxid;

    @FXML
    private Label lblCustomer_fxid;

    @FXML
    private Label lblDesc_fxid;

    @FXML
    private Label lblEntry_fxid;

    @FXML
    private Label lblLocation_fxid;

    @FXML
    private Label lblTitle_fxid;

    @FXML
    private Label lblType_fxid;

    @FXML
    private Pane paneEntry_fxid;

    @FXML
    private ToggleButton togButAppointments_fxid;

    @FXML
    private ToggleButton togButCustomers_fxid;

    @FXML
    private TableView<Appointment> tvAppointments_fxid;

    @FXML
    private TextField txtApptID_fxid;

    @FXML
    private TextField txtDesc_fxid;

    @FXML
    private TextField txtLocation_fxid;

    @FXML
    private TextField txtTitle_fxid;

    @FXML
    private TextField txtType_fxid;

    @FXML
    private DatePicker dtEndDate_fxid;

    @FXML
    private DatePicker dtStartDate_fxid;

    @FXML
    private RadioButton rbMonth_fxid;

    @FXML
    private RadioButton rbWeek_fxid;
    @FXML
    void togButCustomers_Click(javafx.event.ActionEvent actionEvent) throws IOException, SQLException
    {

         Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Customers.fxml"));
        Parent root = fxmlLoader.load();
        ManageCustomers_Controller conManageCust = fxmlLoader.getController();
        conManageCust.LoadCustomers(userID);
        Scene scene = new Scene(root);
        stage.setTitle("Customers");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void btnAdd_Click(ActionEvent event) {

        lblEntry_fxid.setText("Add");
        paneEntry_fxid.setVisible(true);
        bNeedToSave = true;
        ManageControls(true);
        LoadTimeFields(cbStartTime_fxid);
        LoadTimeFields(cbEndTime_fxid);
    }

    @FXML
    void rbApptFilter_Click(ActionEvent event) throws SQLException, ParseException {

         LoadAppointments(userID);
    }
    void LoadTimeFields(ComboBox<String> cbTime)
    {
        int i;
        int j;
        String[] sHour = {"08","09","10","11","12","01","02","03","04","05","06","07","08","09","10"};
        String[] sMin = {"00","15","30","45"};
        String sAMPM = " AM";
        ObservableList<String> hours;
        hours = FXCollections.observableArrayList();
        for (i=0; i<14; i++)
        {
            if (i > 3)
            {
                sAMPM = " PM";
            }
            for (j=0; j<4; j++)
            {
                hours.add(sHour[i] + ":" + sMin[j] + sAMPM);
            }
        }
        cbTime.setItems(hours);
    }
    @FXML
    void btnCancel_Click(ActionEvent event)
    {

        paneEntry_fxid.setVisible(false);
        ClearFields();
        bNeedToSave = false;
        ManageControls(false);
    }

    @FXML
    void btnDelete_Click(ActionEvent event) throws SQLException, ParseException {

        Boolean bOk2Delete = false;
        Appointment clsAppointment = tvAppointments_fxid.getSelectionModel().getSelectedItem();

        if (clsAppointment != null)
        {
            bOk2Delete = ShowAlert("Ok to delete appointment?");
            if (bOk2Delete)
            {
                clsAppointments.RemoveAppointment(clsAppointment);
                LoadAppointments(userID);
            }
        }
        else
        {
            ShowDialog("You must select an Appointment record to delete.");
        }
    }

    @FXML
    void btnEdit_Click(ActionEvent event)
    {

        Appointment clsAppointment = tvAppointments_fxid.getSelectionModel().getSelectedItem();
        if (clsAppointment != null)
        {
            ManageControls(true);
            lblEntry_fxid.setText("Edit");
            LoadTimeFields(cbStartTime_fxid);
            LoadTimeFields(cbEndTime_fxid);
            LoadFields(clsAppointment);
            paneEntry_fxid.setVisible(true);
            bNeedToSave = true;
        }
        else
        {
            ShowDialog("You must select an Appointment record to edit.");
        }
    }

    private void LoadFields(Appointment clsAppointment)
    {
        txtApptID_fxid.setText(String.valueOf(clsAppointment.getAppointment_id()));
        txtTitle_fxid.setText(clsAppointment.getTitle());
        txtDesc_fxid.setText((clsAppointment.getDescription()));
        txtLocation_fxid.setText(clsAppointment.getLocation());
        txtType_fxid.setText(clsAppointment.getType());
        dtStartDate_fxid.setValue(LocalDate.parse(clsAppointment.getStartDateOnly()));
        dtEndDate_fxid.setValue(LocalDate.parse(clsAppointment.getEndDateOnly()));
        String startTime = clsAppointment.getStartTimeOnly();
        cbStartTime_fxid.setValue(FormatTimeToAMPM(startTime));
        String endTime = clsAppointment.getEndTimeOnly();
        cbEndTime_fxid.setValue(FormatTimeToAMPM(endTime));
        cbCustomer_fxid.setValue(String.valueOf(clsAppointment.getCustomer_id()));
        cbContact_fxid.setValue(clsContacts.getContactNameById(clsAppointment.getContact_id()));
    }

    private String FormatTimeToAMPM(String timeIn)
    {
        String sAMPM = "AM";
        String[] timeInRay = timeIn.split((":"));
        Integer timeHours = parseInt(timeInRay[0]);
        if (timeHours >= 12)
        {
            sAMPM = "PM";
            if (timeHours > 12)
            {
                timeHours -= 12;
            }
        }
        String timeOut = String.valueOf(timeHours) + ":" + timeInRay[1] + " " + sAMPM;
        return timeOut;
    }
    private String FormatTimeToMilitary(String timeIn)
    {
        String sAMPM = "AM";
        String timeOut;
        Integer hours;

        if (timeIn.indexOf("PM") > 0)
        {
            sAMPM = "PM";
            timeIn = timeIn.replace(" PM","");
        }
        else
        {
            timeIn = timeIn.replace(" AM","");
        }
        String[] timeInRay = timeIn.split(":");
        hours = Integer.valueOf(timeInRay[0]);
        if ((sAMPM == "PM") && (hours != 12))
        {
            hours += 12;
        }

        timeOut = hours.toString() + ":" + timeInRay[1] + ":00";
        return timeOut;
    }

    @FXML
    void dtEndDate_Action(ActionEvent event)
    {
        if (bDateCheck) {
            LocalDate ldEnd = dtEndDate_fxid.getValue();
            DayOfWeek sDayOfWeek = ldEnd.getDayOfWeek();
            if (sDayOfWeek.getValue() >= 6) {
                ShowDialog("End Date cannot be on the weekend!");
                ResetDate(dtEndDate_fxid);
            } else {
                int iCompare = CompareDates(dtStartDate_fxid.getValue(), ldEnd);
                if (iCompare > 0) {
                    ShowDialog("End Date must be on or after Start Date!");
                    ResetDate(dtEndDate_fxid);
                }
            }
        }

    }

    @FXML
    void dtStartDate_Action(ActionEvent event)
    {
        if (bDateCheck) {
            LocalDate ldStart = dtStartDate_fxid.getValue();
            DayOfWeek sDayOfWeek = ldStart.getDayOfWeek();
            if (sDayOfWeek.getValue() >= 6) {
                ShowDialog("Start Date cannot be on the weekend!");
                ResetDate(dtStartDate_fxid);
            }
        }
    }
    int CompareDates(LocalDate dtStart, LocalDate dtEnd)
    {
        int iCompare = -1;
        if ((dtStart != null) && (dtEnd != null))
        {
            iCompare = dtStart.compareTo(dtEnd);
        }

        return iCompare;
    }
    @FXML
    void btnExit_Click(ActionEvent event) throws SQLException, ParseException {

        if (bNeedToSave)
        {
            bNeedToSave = ShowAlert("Do you want to save before exiting?");
            if (bNeedToSave)
            {
                SaveAppointment();
            }
        }

        System.exit(0);
    }

    private void SaveAppointment() throws SQLException, ParseException {
       Appointment clsAppointmentNew = new Appointment();
       clsAppointmentNew.setAppointment_id(0);
       clsAppointmentNew.setTitle(txtTitle_fxid.getText());
       clsAppointmentNew.setDescription(txtDesc_fxid.getText());
       clsAppointmentNew.setLocation(txtLocation_fxid.getText());
       clsAppointmentNew.setType(txtType_fxid.getText());
       clsAppointmentNew.setStartDate(String.valueOf(dtStartDate_fxid.getValue()) + " " + FormatTimeToMilitary(cbStartTime_fxid.getValue()));
       clsAppointmentNew.setEndDate(String.valueOf(dtEndDate_fxid.getValue()) + " " + FormatTimeToMilitary(cbEndTime_fxid.getValue()));
       clsAppointmentNew.setCustomer_id(parseInt(cbCustomer_fxid.getValue()));
       clsAppointmentNew.setContact(cbContact_fxid.getValue());
       clsAppointmentNew.setContact_id(clsContacts.GetContactID(cbContact_fxid.getValue()));
       clsAppointmentNew.setUser_id(userID);
       if (Objects.equals(lblEntry_fxid.getText(), "Add"))
        {
            //NEW
           clsAppointments.AddAppointment(clsAppointmentNew,true);
        }
       else
       {
           //EDIT
           clsAppointmentNew.setAppointment_id(parseInt(txtApptID_fxid.getText()));
           Appointment clsAppointment = tvAppointments_fxid.getSelectionModel().getSelectedItem();
           clsAppointments.UpdateAppointment(clsAppointment,clsAppointmentNew);
       }
       LoadAppointments(userID);
     }

    @FXML
    void btnSave_Click(ActionEvent event) throws SQLException, ParseException {

        String sMessage = ValidateData();
        if (Objects.equals(sMessage, ""))
        {
            SaveAppointment();
            paneEntry_fxid.setVisible(false);
            ClearFields();
            bNeedToSave = false;
            ManageControls(false);
        }
        else
        {
            ShowDialog(sMessage);
        }
    }
    private String ValidateData() throws SQLException, ParseException {
        String sErrMsg = "";

        if ((Objects.equals(txtTitle_fxid.getText(), "")) || (Objects.equals(txtDesc_fxid.getText(), "")) ||
                (Objects.equals(txtLocation_fxid.getText(), "")) || (Objects.equals(txtType_fxid.getText(), "")) ||
                (dtStartDate_fxid.getValue() == null) || (dtEndDate_fxid.getValue() == null) ||
                (cbStartTime_fxid.getValue() == "") || (cbEndTime_fxid.getValue() == "") ||
                (cbCustomer_fxid.getValue() == "") || (cbContact_fxid.getValue() == ""))
        {
            sErrMsg = "All fields must be filled in!";
        }
        else {
            int iCompare = CompareDates(dtStartDate_fxid.getValue(), dtEndDate_fxid.getValue());
            if (iCompare > 0) {
                sErrMsg = "End Date must be on or after Start Date!";
            }
            else
            {
               boolean bOverlap = CheckOverlap(String.valueOf(dtStartDate_fxid.getValue()) + " " + FormatTimeToMilitary(cbStartTime_fxid.getValue()),
                       String.valueOf(dtEndDate_fxid.getValue()) + " " + FormatTimeToMilitary(cbEndTime_fxid.getValue()), txtApptID_fxid.getText());
               if (bOverlap)
               {
                   sErrMsg = "This appointment overlaps another appointment!";
               }
            }
        }
        return sErrMsg;
    }

    private boolean CheckOverlap(String dtStart, String dtEnd, String apptID) throws SQLException, ParseException {
        boolean bOverlap = false;

        String query = "Select * from appointments where (('" + UserLocUtility.ConvertToUTC(dtStart)  + "' between start and end) or ('" + UserLocUtility.ConvertToUTC(dtEnd) + "' between start and end)) ";
        if (!Objects.equals(apptID, ""))
        {
            query += " and Appointment_ID != " + apptID;
        }
        query += ";";
        DatabaseMySQL myConn = new DatabaseMySQL();
        ResultSet rs = myConn.SubmitQuery(query);
        if (rs.next()) {
            bOverlap = true;
        }
        myConn.CloseConnection();
        return bOverlap;
    }
    private void ClearFields()
    {
        txtApptID_fxid.clear();
        txtTitle_fxid.clear();
        txtDesc_fxid.clear();
        txtLocation_fxid.clear();
        txtType_fxid.clear();
        ResetDate(dtStartDate_fxid);
        ResetDate(dtEndDate_fxid);
        cbStartTime_fxid.setValue("");
        cbEndTime_fxid.setValue("");
        cbCustomer_fxid.setValue("");
        cbContact_fxid.setValue("");
    }
    private void ResetDate(DatePicker dtIn)
    {
        bDateCheck = false;
        dtIn.setValue(LocalDate.now());
        bDateCheck = true;
    }
    public void LoadAppointments(int userIDIn) throws SQLException, ParseException {
        bNeedToSave = false;
        paneEntry_fxid.setVisible(false);
        ClearFields();
        userID = userIDIn;
        clsAppointments = new Appointments();
        clsContacts = new Contacts();

        LoadContacts();
        LoadCustomerIDs();

        DatabaseMySQL myConn = new DatabaseMySQL();

        String query = "SELECT appointment_ID, title, description, location, type, start, end, customer_name, cu.customer_id, user_name, u.user_id, contact_name, co.contact_id FROM Appointments a LEFT JOIN Users u ON a.User_id = u.User_id LEFT JOIN Contacts co ON a.contact_id = co.contact_id LEFT JOIN Customers cu ON a.customer_id = cu.customer_id ";
        Calendar calendar = Calendar.getInstance();
        if (rbWeek_fxid.isSelected())
        {
            int week = calendar.get(Calendar.WEEK_OF_YEAR)-1;
            query += " where week(Start) = " + String.valueOf(week);
        }
        else
        {
            int month = calendar.get(Calendar.MONTH)+1;
            query  += " where month(Start) = " + String.valueOf(month);
        }
        query += " order by Start;";
        ResultSet rs1 = myConn.SubmitQuery(query);
        while (rs1.next()) {
            Appointment clsAppointment = new Appointment();
            clsAppointment.setAppointment_id(rs1.getInt(1));
            clsAppointment.setTitle(rs1.getString(2));
            clsAppointment.setDescription((rs1.getString(3)));
            clsAppointment.setLocation(rs1.getString(4));
            clsAppointment.setType(rs1.getString(5));
            String startLocal = UserLocUtility.ConvertToLocal(rs1.getString(6));
            clsAppointment.setStartDate(startLocal);
            String endLocal = UserLocUtility.ConvertToLocal(rs1.getString(7));
            clsAppointment.setEndDate(endLocal);
            clsAppointment.setContact_id(rs1.getInt(13));
            clsAppointment.setContact(clsContacts.getContactNameById(rs1.getInt(13)));
            clsAppointment.setCustomer_id(rs1.getInt(9));
            clsAppointment.setUser_id(rs1.getInt(11));
            clsAppointments.AddAppointment(clsAppointment,false);
        }

        LoadAppointmentsTable();
        myConn.CloseConnection();
    }

    private void LoadAppointmentsTable()
    {
        ObservableList<Appointment> allAppointments = clsAppointments.getAllAppointments();
        colApptID_fxid.setCellValueFactory(new PropertyValueFactory<>("appointment_id"));
        colTitle_fxid.setCellValueFactory(new PropertyValueFactory<>("title"));
        colDescription_fxid.setCellValueFactory(new PropertyValueFactory<>("description"));
        colLocation_fxid.setCellValueFactory(new PropertyValueFactory<>("location"));
        colContact_fxid.setCellValueFactory(new PropertyValueFactory<>("contact"));
        colType_fxid.setCellValueFactory(new PropertyValueFactory<>("type"));
        colStartDate_fxid.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        colEndDate_fxid.setCellValueFactory(new PropertyValueFactory<>("endDate"));
        colCustomerID_fxid.setCellValueFactory(new PropertyValueFactory<>("customer_id"));
        colUserID_fxid.setCellValueFactory(new PropertyValueFactory<>("user_id"));
        tvAppointments_fxid.setItems(allAppointments);
    }

    private void LoadContacts() throws SQLException
    {
        DatabaseMySQL myConn = new DatabaseMySQL();

        ResultSet rs1 = myConn.SubmitQuery("SELECT contact_id, contact_name, email from Contacts order by contact_name;");
        while (rs1.next())
        {
            Contact clsContact = new Contact();
            clsContact.setContact_name(rs1.getString(2));
            clsContact.setEmail(rs1.getString(3));
            clsContacts.AddContact(clsContact);
        }

        cbContact_fxid.setItems(clsContacts.getAllContactNames());
        myConn.CloseConnection();
    }

    private void  LoadCustomerIDs() throws SQLException {
        DatabaseMySQL myConn = new DatabaseMySQL();

        ObservableList<String> ids;
        ids = FXCollections.observableArrayList();

        ResultSet rs1 = myConn.SubmitQuery("SELECT customer_id from Customers order by customer_id;");
        while (rs1.next())
        {
            ids.add(String.valueOf(rs1.getInt(1)));
        }

        cbCustomer_fxid.setItems(ids);
        myConn.CloseConnection();
    }

    private void ManageControls(boolean bDisable)
    {
        tvAppointments_fxid.setDisable(bDisable);
        btnAdd_fxi.setDisable(bDisable);
        btnEdit_fxid.setDisable(bDisable);
        btnDelete_fxid.setDisable(bDisable);
    }

    public static void ShowDialog(String sMsg)
    {
        Dialog<String> dialog = new Dialog<String>();
        dialog.setTitle("Message");
        ButtonType type = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.setContentText(sMsg);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }

    private Boolean ShowAlert(String sMsg)
    {
        AtomicReference<Boolean> bYes = new AtomicReference<>(false);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(sMsg);
        ButtonType yesButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
        //ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        //alert.getButtonTypes().setAll(yesButton, noButton, cancelButton);
        alert.getButtonTypes().setAll(yesButton, noButton);
        alert.showAndWait().ifPresent(type -> {
            if (type == yesButton) {
                bYes.set(true);
            }});
        return bYes.get();
    }

}

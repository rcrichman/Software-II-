package srcCode;
import javax.xml.transform.Result;
import java.sql.*;

/**
 * Develops connections between code and database
 *
 * Inserts and removes database data through queries
 */
public class DatabaseMySQL
{
    private Connection myConn;

    public void OpenConnection() throws SQLException {
        myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/client_schedule", "sqlUser", "Passw0rd!");
    }

    public void CloseConnection() throws SQLException {
        if (myConn != null) {myConn.close();}
    }

    public ResultSet SubmitQuery(String query) throws SQLException
    {
        if (myConn == null)
        {
            OpenConnection();
        }
        Statement stmt = myConn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        return rs;
    }

    public int SubmitUpdateQuery(String query, boolean returnID) throws SQLException
    {
        int insertID = 0;

        if (myConn == null)
        {
            OpenConnection();
        }
        // INSERT THE RECORD
        PreparedStatement stmt = myConn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
        stmt.executeUpdate();

        //RETURN THE UNIQUE ID FOR THE RECORD THAT WAS JUST INSERTED
        if (returnID)
        {
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                insertID = rs.getInt(1);
            }
        }
        return insertID;
    }
}

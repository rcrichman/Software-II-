package srcCode;
import java.util.TimeZone;
import java.time.ZoneId;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.function.BiFunction;

public class UserLocUtility {

    public static TimeZone GetTimeZone() {
        return TimeZone.getDefault();
    }

    public static LocalDateTime GetCurrentTime() {
        return LocalDateTime.now(ZoneId.systemDefault());
    }

    public static Locale GetUserLocale() {
        return Locale.getDefault();
    }

    public static String GetTranslation(Integer msgIndex)
    {
        String retMsg = "";
        switch (msgIndex)
        {
            case(1):
                retMsg = GetMessage.apply("Scheduling Application","Application de planification");
                break;
            case(2):
                retMsg = GetMessage.apply("Login","Se connecter");
                break;
            case(3):
                retMsg = GetMessage.apply("Username:","Nom d'utilisateur:");
                break;
            case(4):
                retMsg = GetMessage.apply("Password:","Mot de passe:");
                break;
            case(5):
                retMsg = GetMessage.apply("Exit","Sortie");
                break;
            case(6):
                retMsg = GetMessage.apply("User's Location:","Emplacement de l'utilisateur:");
                break;
            case (7):
                retMsg = GetMessage.apply("Please enter a username and password!","Veuillez entrer un nom d'utilisateur et un mot de passe!");
                break;
            case (8):
                retMsg = GetMessage.apply("Invalid username or password!","Nom d'utilisateur ou mot de passe invalide!");
                break;
            case (9):
                retMsg = GetMessage.apply("No upcoming appointments!","Aucun rendez-vous à venir!");
                break;
            case (10):
                retMsg = GetMessage.apply("Message","Message");
                break;
            case (11):
                retMsg = GetMessage.apply("Ok","D'accord");
                break;
            case (12):
                retMsg = GetMessage.apply("Upcoming appointment: ","Rendez-vous à venir: ");
                break;

        }
        return retMsg;

    }
    public static boolean IsFrenchSpeaking() {
        return GetUserLocale().getLanguage().equals("fr") || GetUserLocale().getCountry().equals("CA")
                || GetUserLocale().getCountry().equals("FR") || GetUserLocale().getCountry().equals("BE")
                || GetUserLocale().getCountry().equals("CH") || GetUserLocale().getCountry().equals("LU");
    }

    // Lambda expression to format the UTC offset
    BiFunction<Integer, Integer, String> FormatUtcOffset = (hours, minutes) ->
    {
        String sign = (hours >= 0) ? "+" : "-";
        return String.format("UTC %s%02d:%02d", sign, Math.abs(hours), minutes);
    };

    // Lambda expression for language-specific messages
    static BiFunction<String, String, String> GetMessage = (englishMsg, frenchMsg) ->
    {
       return IsFrenchSpeaking() ? frenchMsg : englishMsg;
       //return IsFrenchSpeaking() ? englishMsg : frenchMsg;   //TEST
    };
}

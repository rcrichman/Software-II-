package srcCode;

import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import javax.xml.crypto.Data;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

public class SchedulingMain_Controller
{
    private int userID;
    @FXML
    public Button btnExit_fxid;

    @FXML
    public Button btnLogin_fxid;

    @FXML
    private Label lblMessage_fxid;

    @FXML
    public Label lblAppname_fxid;

    @FXML
    public Label lblLocation_fxid;

    @FXML
    public Label lblLogin_fxid;

    @FXML
    public Label lblPassword_fxid;

    @FXML
    public Label lblUsername_fxid;

    @FXML
    private PasswordField txtPassword_fxid;

    @FXML
    private TextField txtUsername_fxid;

    @FXML
    void btnExit_Action(javafx.event.ActionEvent actionEvent) {
       System.exit(0);
    }

    @FXML
    void btnLogin_Action(javafx.event.ActionEvent actionEvent) throws IOException, SQLException
    {

        String sMessage = ValidateUser(txtUsername_fxid.getText(),txtPassword_fxid.getText());
        if (!Objects.equals(sMessage, ""))
        {
           lblMessage_fxid.setText(sMessage);
           lblMessage_fxid.setVisible(true);
        }
        else
        {
            lblMessage_fxid.setVisible(false);
            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Customers.fxml"));
            Parent root = fxmlLoader.load();
            ManageCustomers_Controller conManageCust = fxmlLoader.getController();
            conManageCust.LoadCustomers(userID);
            Scene scene = new Scene(root);
            stage.setTitle("Customers");
            stage.setScene(scene);
            stage.show();
        }
    }

    private String ValidateUser(String sUsername, String sPassword) throws SQLException
    {

        String sRetVal = "";
        DatabaseMySQL myConn = new DatabaseMySQL();

        if ((Objects.equals(sUsername, "")) || (Objects.equals(sPassword, "")))
        {
            sRetVal = UserLocUtility.GetTranslation(7);
        }
        else
        {
            ResultSet rs = myConn.SubmitQuery("SELECT user_id FROM Users WHERE user_name = '" + sUsername + "' AND password = '" + sPassword + "'");
            if (!rs.next())
            {
                sRetVal = UserLocUtility.GetTranslation(8);
            }
            else
            {
                userID = rs.getInt(1);
                CheckAppointments();
            }
            myConn.CloseConnection();
        }
        return sRetVal;
    }
    private void CheckAppointments() throws SQLException
    {

        String sMsg = UserLocUtility.GetTranslation(9);

         DatabaseMySQL myConn = new DatabaseMySQL();
        LocalDateTime dateTime = LocalDateTime.now().plusMinutes(15);
        String query = "Select appointment_id, start from appointments where '" + dateTime.toString() + "' between start and end;";
        ResultSet rs = myConn.SubmitQuery(query);
        while (rs.next())
        {
           sMsg = UserLocUtility.GetTranslation(12) + rs.getInt(1) + " - " + rs.getString(2);
        }

        myConn.CloseConnection();
        ShowDialog(sMsg);
    }
    private Boolean ShowAlert(String sMsg)
    {

        AtomicReference<Boolean> bYes = new AtomicReference<>(false);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText(sMsg);
        ButtonType yesButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().setAll(yesButton, noButton, cancelButton);
        alert.showAndWait().ifPresent(type -> {
            if (type == yesButton) {
                bYes.set(true);
            }});
        return bYes.get();

    }

    public static void ShowDialog(String sMsg)
    {
        Dialog<String> dialog = new Dialog<String>();
        dialog.setTitle(UserLocUtility.GetTranslation(10));
        ButtonType type = new ButtonType(UserLocUtility.GetTranslation(11), ButtonBar.ButtonData.OK_DONE);
        dialog.setContentText(sMsg);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    public static Boolean IsNumber(String strVal, Boolean bIncludeDecimal)
    {

        Integer iCount=0;
        String sNumbers = "0123456789";
        char decimalPoint = '.';

        if (bIncludeDecimal) {
            if (Objects.equals(strVal,"."))
            {
                return false;
            }
            //MAKE SURE THE USER DIDN'T JUST PUT MORE THAN ONE DECIMAL POINT
            for (int i = 0; i < strVal.length(); i++) {
                if (strVal.charAt(i) == decimalPoint) {
                    iCount++;
                }
            }
            if (iCount > 1)
            {
                return false;
            }
            sNumbers += ".";
        }
        for (int i = 0; i < strVal.length(); i++)
        {
            if (sNumbers.indexOf(strVal.charAt(i)) < 0)
            {
                return false;  // NOT A NUMBER
            }
        }
        return true;  // IS A NUMBER
    }
}

package srcCode;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public class Customers
{
    private ObservableList<Customer> allCustomers;
    private Integer customerID;

    public Customers()
    {
        customerID = 0;
        allCustomers = FXCollections.observableArrayList();
    }

    public void AddCustomer(Customer newCustomer,boolean bStoreIt) throws SQLException
    {
        if (bStoreIt) {
            DatabaseMySQL myConn = new DatabaseMySQL();
            if (newCustomer.getCustomer_id() == 0) {
                String query = "INSERT INTO Customers (customer_name, address, postal_code, phone, division_id) VALUES('" +
                        newCustomer.getCustomer_name() + "','" + newCustomer.getAddress() + "','" + newCustomer.getPostal_code() + "','" +
                        newCustomer.getPhone() + "'," + newCustomer.getDivision_id() + ");";
                customerID = myConn.SubmitUpdateQuery(query, true);
                newCustomer.setCustomer_id(customerID);
            } else {
                //UPDATE
                String query = "UPDATE Customers SET customer_name='" + newCustomer.getCustomer_name() + "', address='" + newCustomer.getAddress() + "', postal_code='" +
                        newCustomer.getPostal_code() + "', phone='" + newCustomer.getPhone() + "', division_id=" + newCustomer.getDivision_id() + " WHERE customer_id = " +
                        newCustomer.getCustomer_id() + ";";
                myConn.SubmitUpdateQuery(query, false);
            }
            myConn.CloseConnection();
        }
        allCustomers.add(newCustomer);
    }
    public void UpdateCustomer(Customer originalCustomer, Customer updatedCustomer) throws SQLException {
        allCustomers.remove(originalCustomer);
        AddCustomer(updatedCustomer,true);
    }
    public void RemoveCustomer(Customer removedCustomer) throws SQLException {
        DatabaseMySQL myConn = new DatabaseMySQL();

        String query = "DELETE FROM Appointments WHERE Customer_ID =" + removedCustomer.getCustomer_id() + ";";
        myConn.SubmitUpdateQuery(query,false);
        query = "DELETE FROM Customers WHERE Customer_ID =" + removedCustomer.getCustomer_id() + ";";
        myConn.SubmitUpdateQuery(query,false);
        myConn.CloseConnection();
        allCustomers.remove(removedCustomer);
    }
    public ObservableList<Customer> getAllCustomers()
    {
        return allCustomers;
    }
    public Integer getNumCustomers()
    {
        return allCustomers.size();
    }
}

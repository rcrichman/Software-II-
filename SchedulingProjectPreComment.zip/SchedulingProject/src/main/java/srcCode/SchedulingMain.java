package srcCode;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;

public class SchedulingMain extends Application
{
    @Override
    public void start(Stage primaryStage) throws IOException
    {

        FXMLLoader fxmlLoader = new FXMLLoader(SchedulingMain.class.getResource("Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        SchedulingMain_Controller conSchedulingMain = fxmlLoader.getController();
        conSchedulingMain.btnLogin_fxid.setText(UserLocUtility.GetTranslation(2));
        conSchedulingMain.btnExit_fxid.setText(UserLocUtility.GetTranslation(5));
        conSchedulingMain.lblAppname_fxid.setText(UserLocUtility.GetTranslation(1));
        conSchedulingMain.lblUsername_fxid.setText(UserLocUtility.GetTranslation(3));
        conSchedulingMain.lblPassword_fxid.setText(UserLocUtility.GetTranslation(4));
        conSchedulingMain.lblLogin_fxid.setText((UserLocUtility.GetTranslation(2)));
        conSchedulingMain.lblLocation_fxid.setText(UserLocUtility.GetTimeZone().getDisplayName());
        primaryStage.setTitle(UserLocUtility.GetTranslation(1));
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args)
    {
        launch();
    }


}
package srcCode;
import java.sql.*;

public class DatabaseMySQL
{
    private Connection myConn;

    public void OpenConnection() throws SQLException {
        myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/client_schedule", "sqlUser", "Passw0rd!");
    }

    public void CloseConnection() throws SQLException {
        if (myConn != null) {myConn.close();}
    }

    public ResultSet SubmitQuery(String query) throws SQLException
    {
        if (myConn == null)
        {
            OpenConnection();
        }
        Statement stmt = myConn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        return rs;
    }
}

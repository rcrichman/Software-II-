package srcCode;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public class Customers
{
    private ObservableList<Customer> allCustomers;
    private Integer customerID;

    public Customers()
    {
        customerID = 0;
        allCustomers = FXCollections.observableArrayList();
    }

    public void AddCustomer(Customer newCustomer) throws SQLException
    {
        if (newCustomer.getCustomer_id() == 0)
        {
            DatabaseMySQL myConn = new DatabaseMySQL();

            String query = "INSERT INTO Customers (customer_name, address, postal_code, phone, division_id) VALUES('" +
                    newCustomer.getCustomer_name() + "','" + newCustomer.getAddress() + "','" + newCustomer.getPostal_code() + "','" +
                    newCustomer.getPhone() + "'," + newCustomer.getDivision_id() + ");";
            customerID = myConn.SubmitUpdateQuery(query,true);
            newCustomer.setCustomer_id(customerID);
            myConn.CloseConnection();
        }

        allCustomers.add(newCustomer);
    }
    public void UpdateCustomer(Customer originalCustomer, Customer updatedCustomer)
    {
        allCustomers.remove(originalCustomer);
        allCustomers.add(updatedCustomer);
    }
    public void RemoveCustomer(Customer removedCustomer)
    {
        allCustomers.remove(removedCustomer);
    }
    public ObservableList<Customer> getAllCustomers()
    {
        return allCustomers;
    }
    public Integer getNumCustomers()
    {
        return allCustomers.size();
    }
}
